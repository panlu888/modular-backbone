define([
	'jquery',
	'underscore',
	'backbone',
	'models/person',
	'text!templates/thirdTemplate.html'

], function($, _, Backbone, PersonModel, thirdTemplate) {
	var thirdPage = Backbone.View.extend({
		el: $('#content'),

		
		render: function() {
    	var compiledTemplate = _.template(thirdTemplate, this.model.toJSON());
    	this.$el.html(compiledTemplate);
    }
	});

	return thirdPage;
});